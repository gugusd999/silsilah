<?php 

    echo "echo";
    shell_exec("git pull origin main");
