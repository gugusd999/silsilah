<?php
$this->load->view("back/template/header");
$this->load->view("back/template/navbartop");
$this->load->view("back/template/navbarleft");


?>





<div class="main-content">
    <div class="main-content-inner">
        <div class="breadcrumbs ace-save-state" id="breadcrumbs">
            <ul class="breadcrumb">
                <li>
                    <i class="ace-icon fa fa-home home-icon"></i>
                    <a href="#">Home</a>
                </li>
                <li class="active">Dashboard</li>
            </ul><!-- /.breadcrumb -->


        </div>

        <div class="page-content">





        </div><!-- /.page-content -->
    </div>
</div><!-- /.main-content -->



<?php
$this->load->view("back/template/footer");

?>